import React from "react";
import { Banknote, Flame, BarChart2 } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white font-['Playfair Display']">
      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center text-center px-6 py-24 overflow-hidden">
        <div className="absolute inset-0 opacity-20 blur-2xl bg-gradient-to-br from-purple-500 via-fuchsia-600 to-pink-500"></div>
        <h1 className="relative z-10 text-5xl md:text-7xl font-bold tracking-tight mb-4">Rizze</h1>
        <p className="relative z-10 text-lg md:text-xl max-w-xl text-gray-300 mb-8">
          Seductive rewards. Luxurious control. Rent, bills, and life—now they pay you back.
        </p>
        <button className="relative z-10 bg-white text-black font-semibold px-6 py-3 rounded-full hover:bg-gray-200 transition">
          Join the Waitlist
        </button>
      </section>

      {/* Features Section */}
      <section className="px-6 py-16 grid grid-cols-1 md:grid-cols-3 gap-10 max-w-6xl mx-auto">
        <div className="flex flex-col items-start">
          <Banknote className="text-pink-500 mb-2 w-6 h-6" />
          <h3 className="text-xl font-semibold mb-2">Rent Rewards</h3>
          <p className="text-gray-400">
            Pay rent by card. Landlord gets paid. You earn Rizze Points every month.
          </p>
        </div>
        <div className="flex flex-col items-start">
          <BarChart2 className="text-yellow-500 mb-2 w-6 h-6" />
          <h3 className="text-xl font-semibold mb-2">Drip Tiers</h3>
          <p className="text-gray-400">
            Your credit score and spending unlock sexy status: Bronze, Silver, Gold, Rizze Black.
          </p>
        </div>
        <div className="flex flex-col items-start">
          <Flame className="text-red-500 mb-2 w-6 h-6" />
          <h3 className="text-xl font-semibold mb-2">Workouts = Points</h3>
          <p className="text-gray-400">
            Sync your steps. Sweat it out. Earn rewards for staying active and hot.
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-900 px-6 py-20 text-center">
        <h2 className="text-4xl font-bold mb-4">Rizz up your life</h2>
        <p className="text-gray-400 mb-8">
          Luxury should reward you back. Join early. Become unforgettable.
        </p>
        <button className="bg-white text-black font-semibold px-6 py-3 rounded-full hover:bg-gray-200 transition">
          Reserve Your Spot
        </button>
      </section>

      {/* Footer */}
      <footer className="text-center text-gray-500 text-sm py-6">
        &copy; {new Date().getFullYear()} Rizze. All rights reserved.
      </footer>
    </div>
  );
}
