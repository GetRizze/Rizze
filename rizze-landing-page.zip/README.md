# Rizze – Luxury Rewards Homepage

A sleek React + Tailwind landing page for Rizze – the seductive rewards app built for rent, bills, and lifestyle spenders.